<?php if($cocok == 'Y'): ?>
	<button style="margin-top: 10px" class="btn btn-primary" id="delete-all">Hapus Semua Siswa</button>
<?php else: ?>
	<p style="margin-top: 10px" class="alert alert-danger">Password yang Anda inputkan tidak cocok!</p>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\CBTSMEPRI\resources\views/siswa/tombol_hapus.blade.php ENDPATH**/ ?>