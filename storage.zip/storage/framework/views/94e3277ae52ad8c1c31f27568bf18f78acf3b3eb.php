
<?php $__env->startSection('title', 'Ubah kelas'); ?>
<?php $__env->startSection('breadcrumb'); ?>
  <h1>Master Data</h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(url('/home')); ?>"><i class="fa fa-home"></i> Home</a></li>
    <li class="active">Kelas</li>
  </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <?php include(app_path().'/functions/myconf.php'); ?>
  <div class="col-md-8">
    <div class="box box-primary">
      <div class="box-header with-border">
        <h3 class="box-title"><i class="fa fa-edit" aria-hidden="true"></i> Ubah Distribusi</h3>
        <div class="pull-right">
          <button type="button" class="btn btn-primary" id="btn-create"><i class="fa fa-edit"></i> Buat Distribusi</button>
        </div>
      </div>
      <div class="box-body">
        <div class="col-sm-12">
          <div class="col-sm-12">
            <form id="form-distribusi" style="" class="form-horizontal">
            <div class="form-group">
                <label for="id_soal" class="col-sm-2 control-label">Mata Pelajaran</label>
                <div class="col-sm-10">
                <input type="hidden" name="id" value="<?php echo e($distribusis); ?>">
                <select class="form-control" name="id_soal" id="id_soal" placeholder="Soal">
                    <?php $__empty_1 = true; $__currentLoopData = $distribusi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <option value="<?php echo e($ds->id_soal); ?>"><?php echo e($ds->soal->paket); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                    <?php $__empty_1 = true; $__currentLoopData = $soal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $soal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <option value="<?php echo e($soal->id); ?>"><?php echo e($soal->paket); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label for="id_kelas" class="col-sm-2 control-label">Kelas</label>
                <div class="col-sm-10">
                  <select class="form-control" name="id_kelas" id="id_kelas" placeholder="Kelas">
                    <?php $__empty_1 = true; $__currentLoopData = $distribusi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <option value="<?php echo e($ds->id_kelas); ?>"><?php echo e($ds->kelas->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                    <?php $__empty_1 = true; $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <option value="<?php echo e($kelas->id); ?>"><?php echo e($kelas->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label for="save" class="col-sm-2 control-label">&nbsp</label>
                <div class="col-sm-10">
                  <div class="alert alert-danger" id="notif" style="display: none; margin: 0 auto 10px"></div>
                  <button type="button" class="btn btn-primary" id="save">Simpan</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
  <script>
    $(document).ready(function (){
      $('#save').click(function() {
        $('#notif').hide();
        var formData = $('#form-distribusi').serialize();
        $.ajax({
          type: 'POST',
          url: "<?php echo e(url('crud/simpan-distribusi')); ?>",
          data: formData,
          success: function(data) {
            if (data == 1) {
              window.location.href = "<?php echo e(url('distribusi')); ?>";
            }else{
              $('#notif').html(data).show();
            }
          }
        })
      });
    });
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CBTSMEPRI\resources\views/distribusi/form/ubah.blade.php ENDPATH**/ ?>