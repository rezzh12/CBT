
<?php $__env->startSection('title', 'Ti-Xam - '.Auth::user()->nama); ?>
<?php $__env->startSection('breadcrumb'); ?>
  <h1>Detail Soal Ujian</h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(url('/home')); ?>"><i class="fa fa-home"></i> Home</a></li>
    <li><a href="<?php echo e(url('/siswa/ujian')); ?>">Ujian</a></li>
    <li class="active">Selesai Ujian</li>
  </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="col-md-12">
	  <div class="box box-primary">
	    <div class="box-header with-border">
	      <h3 class="box-title">Selesai Ujian</h3>
	    </div>
	    <div class="box-body">
	    	<center>
	    		<!-- <?php if($soal->kkm < $nilai): ?>
		    		<i class="fa fa-smile-o" aria-hidden="true" style="font-size: 50pt; color: #18b10f;"></i>
		    	<?php else: ?>
		    		<i class="fa fa-frown-o" aria-hidden="true" style="font-size: 50pt; color: #d61515;"></i>
		    	<?php endif; ?> -->
	    		<i class="fa fa-smile-o" aria-hidden="true" style="font-size: 50pt; color: #18b10f;"></i>
	    		<p style="color: #848383; font-size: 14pt; margin: 0">Selamat, kamu telah berhasil menyelesaikan ujian <b><?php echo e($soal->paket); ?></b></p>
	    		<!-- <p style="color: #848383; font-size: 14pt; margin: 0"><small>Nilai yang kamu dapat:</small> <b><?php echo e(number_format($nilai)); ?></b></p> -->
	    		<p style="color: #848383; font-size: 14pt; margin: 0">
	    			Nilai kamu sudah keluar, tapi rahasia dulu ya. Dan jangan lupa selalu belajar dengan giat ya!
	    			<!-- <?php if($soal->kkm < $nilai): ?>
	    				Selamat kamu lulus KKM ujian ini.
	    			<?php else: ?>
	    				Sepertinya nilai kamu belum cukup untuk KKM (<b><?php echo e(number_format($soal->kkm)); ?></b>) ujian ini. Belajar yang giat ya!
	    			<?php endif; ?> -->
	    		</p>
	    	</center>
	    </div>
	  </div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CBTSMEPRI\resources\views/halaman-siswa/finish.blade.php ENDPATH**/ ?>