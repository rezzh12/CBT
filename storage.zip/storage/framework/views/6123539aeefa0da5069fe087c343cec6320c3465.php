<?php use Carbon\Carbon; ?>

<?php $__env->startSection('title', 'CBT SMEPRI - Aplikasi Ujian Berbasis Komputer'); ?>
<?php $__env->startSection('breadcrumb'); ?>
  <h1>Dashboard</h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
    <li class="active">Selamat datang</li>
  </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <?php include(app_path().'/functions/myconf.php'); ?>
  <?php if(Auth::user()->status == 'A'): ?>
    <div class="callout callout-info">
      <h4>Hai, <b><?php echo e(Auth::user()->nama); ?> (Admin)</b></h4>
      <p>Anda adalah admin aplikasi ini. Selalu pantau github rezzh12 untuk mendapatkan update terbaru. Dan yuk ajak guru-guru menjadi kontributor <a href="#">rezamuhammad1924@gmail.com</a>.</p>
    </div>
  <?php endif; ?>
  <?php if(Auth::user()->status == 'A' || Auth::user()->status == 'G'): ?>
    <div class="col-md-3 col-sm-4 col-xs-12">
      <div class="info-box">
        <span class="info-box-icon bg-aqua"><i class="ion ion-person-stalker"></i></span>
        <div class="info-box-content">
          <span class="info-box-text">Jumlah Siswa</span>
          <span class="info-box-number"><?php echo e(number_format($siswas)); ?> <small>siswa</small></span>
        </div>
      </div>
    </div>
    <div class="col-md-3 col-sm-4 col-xs-12">
      <div class="info-box">
        <span class="info-box-icon bg-yellow"><i class="ion ion-person-stalker"></i></span>
        <div class="info-box-content">
          <span class="info-box-text">Jumlah Guru</span>
          <span class="info-box-number"><?php echo e(number_format($gurus)); ?> <small>guru</small></span>
        </div>
      </div>
    </div>
    <div class="col-md-3 col-sm-4 col-xs-12">
      <div class="info-box">
        <span class="info-box-icon bg-green"><i class="ion ion-ios-list-outline"></i></span>
        <div class="info-box-content">
          <span class="info-box-text">Jumlah Paket Soal</span>
          <span class="info-box-number"><?php echo e(number_format($pakets)); ?> <small>paket</small></span>
          <span><b><?php echo e(number_format($soals)); ?></b> <small>soal</small></span>
        </div>
      </div>
    </div>
    <div class="col-md-3 col-sm-4 col-xs-12">
      <div class="info-box">
        <span class="info-box-icon bg-red"><i class="ion ion-pie-graph"></i></span>
        <div class="info-box-content">
          <span class="info-box-text">Jumlah Materi</span>
          <span class="info-box-number"><?php echo e(number_format($materis)); ?> <small>materi</small></span>
        </div>
      </div>
    </div>
    <div class="clearfix"></div>
    <div class="col-md-8">
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title">Paket soal</h3>
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
          </div>
        </div>
        <div class="box-body">
          <table class="table table-hover table-striped" id="table_soal">
            <?php if(Auth::user()->status == 'G'): ?>
              <caption>Data paket soal yang Anda buat</caption>
            <?php else: ?>
              <caption>Data paket soal</caption>
            <?php endif; ?>
            <thead>
              <tr>
                <th>Nama Paket</th>
                <th>Deskripsi</th>
                <th>Jenis</th>
                <th style="text-align: center;">KKM</th>
                <th style="text-align: center; width: 70px">Waktu</th>
                <th style="text-align: center; width: 110px">Aksi</th>
              </tr>
            </thead>
          </table>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="box box-success">
        <div class="box-header with-border">
          <h3 class="box-title">Aktifitas Terkini</h3>
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
            </button>
            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
          </div>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <ul class="products-list product-list-in-box">
            <?php if($aktifitas->count()): ?>
            <?php $__currentLoopData = $aktifitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_aktifitas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="item">
              <div class="product-img">
                <?php if($data_aktifitas->dataAktifitasUser->gambar != ""): ?>
                <img src="<?php echo e(url('/assets/img/user/'.$data_aktifitas->dataAktifitasUser->gambar)); ?>" alt="user img">
                <?php else: ?>
                <img src="<?php echo e(url('/assets/img/noimage.jpg')); ?>" alt="user img">
                <?php endif; ?>
              </div>
              <div class="product-info">
                <a href="javascript:void(0)" class="product-title"><?php echo e($data_aktifitas->dataAktifitasUser->nama); ?>

                  <span class="label label-warning pull-right"><?php echo e($data_aktifitas->created_at->diffForHumans()); ?></span>
                </a>
                <span class="product-description">
                  <?php echo e($data_aktifitas->nama); ?>

                </span>
              </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          </ul>
          <a href="<?php echo e(url('/activity')); ?>" class="btn btn-info btn-sm btn-block">Selengkapnya</a>
        </div>
      </div>
      <div class="box box-warning">
        <div class="box-header with-border">
          <h3 class="box-title" style="color: coral"><i class="fa fa-info-circle"></i> Informasi</h3>
        </div>
        <div class="box-body">
          <p>Terimakasih telah menggunakan aplikasi ujian (<b>CBT SMEPRI</b>) dari <a href="#">CBT SMEPRI</a> ini. Untuk melakukan update sangat disarankan menggunakan <i>git</i> dengan mengetikan <br><i>git pull origin master</i>.</p>
        </div>
      </div>
    </div>
  <?php else: ?>
    <div class="alert" style="background: #fff; border: solid thin #d8d5d5;">
      <p>Hai <?php echo e(Auth::user()->nama); ?>, Selamat datang di CBTSMEPRI. Disini kamu bisa temukan materi yang telah disiapkan oleh Guru serta mengerjakan soal latihan dan ujian.</p>
      <p>Pantau perkembangan kamu dengan melihat nilai-nilai latihan dan ujian dengan cepat.</p>
      <p>Apabila ada hal yang kurang dipahami, bisa ditanyakan kepada Guru atau operator sekolah yang mengelola aplikasi ini.</p>
    </div>
  <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(url('assets/plugins/datatables/media/css/dataTables.bootstrap.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('assets/plugins/datatables/extensions/Responsive/css/responsive.dataTables.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('assets/plugins/datatables/extensions/FixedHeader/css/fixedHeader.bootstrap.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(url('assets/dist/js/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/plugins/datatables/media/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/plugins/datatables/media/js/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/plugins/datatables/extensions/Responsive/js/dataTables.responsive.js')); ?>"></script>
<script src="<?php echo e(url('assets/plugins/datatables/extensions/FixedHeader/js/dataTables.fixedHeader.js')); ?>"></script>
  <script>
  $(document).ready(function (){
    table_soal = $('#table_soal').DataTable({
      processing: true,
      serverSide: true,
      responsive: true,
      lengthChange: true,
      ajax: '<?php echo e(route("elearning.get-soal-home")); ?>',
        columns: [
        {data: 'paket', name: 'paket', orderable: true, searchable: true },
        {data: 'deskripsi', name: 'deskripsi', orderable: true, searchable: true },
        {data: 'jenis', name: 'jenis', orderable: true, searchable: true },
        {data: 'kkm', name: 'kkm', orderable: true, searchable: true },
        {data: 'waktu', name: 'waktu', orderable: true, searchable: true },
        {data: 'action', name: 'action', orderable: false, searchable: false, },
      ],
      "drawCallback": function (setting) {}
    });
    $("#btn-wrap-info").click(function() {
      $(this).hide();
      $("#wrap-info").show();
    });
  });
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CBTSMEPRI\resources\views/home.blade.php ENDPATH**/ ?>