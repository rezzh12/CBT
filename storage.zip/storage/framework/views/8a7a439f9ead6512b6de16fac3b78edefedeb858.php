
<?php $__env->startSection('title', 'CBT SMEPRI - '.Auth::user()->nama); ?>
<?php $__env->startSection('breadcrumb'); ?>
  <h1><i class="fa fa-check-square"></i> Soal Ujian</h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(url('/home')); ?>"><i class="fa fa-home"></i> Home</a></li>
    <li class="active">Hi, <?php echo e(Auth::user()->nama); ?></li>
  </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="col-md-12">
	  <div class="box box-primary">
	    <div class="box-header with-border">
	      <h3 class="box-title">Soal yang bisa dikerjakan sekarang.</h3>
	      <div class="box-tools pull-right">
	        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
	      </div>
	    </div>
	    <div class="box-body">
		    <div class="row">
		    	<?php if($pakets->count()): ?>
			    	<?php $__currentLoopData = $pakets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paket_soal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    		<?php
			    			$check = App\Models\jawab::where('id_soal', $paket_soal->id_soal)->where('id_user', Auth::user()->id)->count();
			    		?>
				    	<div class="col-sm-4">
				    		<?php if($check >=20): ?>
			    				<a href="<?php echo e(url('siswa/ujian/finish/'.$paket_soal->id_soal)); ?>">
						    		<div class="info-box bg-yellow">
					            <span class="info-box-icon"><i class="fa fa-check-circle-o" aria-hidden="true"></i></span>
					            <div class="info-box-content">
					              <span class="info-box-text"><?php echo e($paket_soal->soal->paket); ?></span>
					              <div class="progress">
					                <div class="progress-bar" style="width: 100%"></div>
					              </div>
				                <span class="progress-description"><?php echo e($paket_soal->soal->deskripsi); ?></span>
				                <span>Kamu sudah menyelesaikan ujian ini.</span>
					            </div>
					          </div>
						    	</a>
				    		<?php else: ?>
				    			<a href="<?php echo e(url('siswa/ujian/detail/'.$paket_soal->id_soal)); ?>">
						    		<div class="info-box bg-green">
					            <span class="info-box-icon"><i class="fa fa-check-square-o"></i></span>
					            <div class="info-box-content">
					              <span class="info-box-text"><?php echo e($paket_soal->soal->paket); ?></span>
					              <!-- <span class="info-box-number"></span> -->
					              <div class="progress">
					                <div class="progress-bar" style="width: 100%"></div>
					              </div>
				                <span class="progress-description"><?php echo e($paket_soal->soal->deskripsi); ?></span>
					            </div>
					          </div>
						    	</a>
			    			<?php endif; ?>
				    	</div>
			    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    	<?php else: ?>
						<div class="col-md-12">Belum ada soal yang bisa dikerjakan.</div>
		    	<?php endif; ?>
		    </div>
	    </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
<style>
	.bg-aqua{
		background-color: #117e98 !important;
	}
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CBTSMEPRI\resources\views/halaman-siswa/ujian.blade.php ENDPATH**/ ?>