
<?php $__env->startSection('title', 'Data kelas'); ?>
<?php $__env->startSection('breadcrumb'); ?>
  <h1>Detail Kelas</h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(url('/home')); ?>"><i class="fa fa-home"></i> Home</a></li>
    <li><a href="<?php echo e(url('/master/kelas')); ?>">Kelas</a></li>
    <li class="active">Detail</li>
  </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php include(app_path().'/functions/myconf.php'); ?>
<div class="col-md-9">
  <div class="box box-primary">
  	<div class="box-header with-border">
      <h3 class="box-title"><?php echo e($kelas->nama); ?></h3>
      <div class="pull-right">
        <a href="<?php echo e(url('master/kelas/ubah/'.$kelas->id)); ?>" class="btn btn-success" id="btn-create"><i class="fa fa-edit"></i> Tambah Siswa</a>
        <a href="<?php echo e(url('master/kelas/ubah/'.$kelas->id)); ?>" class="btn btn-primary" id="btn-create"><i class="fa fa-edit"></i> Ubah Kelas</a>
        <button type="button" class="btn btn-danger" id="btn-siswa"><i class="fa fa-trash"></i> Kosongkan Kelas</button>
      </div>
    </div>
    <div class="box-body">
    	<table class="table table-hover table-condensed" id="table_detail_kelas">
    		<caption><i>Daftar siswa di kelas <?php echo e($kelas->nama); ?>.</i></caption>
    		<thead>
    			<tr>
    				<th>Nama</th>
    				<th>NIS</th>
    				<th>NISN</th>
    				<th>Jenis kelamin</th>
    				<th style="text-align: center">Aksi</th>
    			</tr>
    		</thead>
    	</table>
    </div>
  </div>
</div>
<div class="col-md-3">
  <div class="box box-warning">
  	<div class="box-header with-border">
      <h3 class="box-title" style="color: darkorange"><i class="fa fa-info-circle"></i> Informasi</h3>
    </div>
    <div class="box-body">
	    <table class="table table-striped">
	    	<tr>
	    		<td>Nama</td>
	    		<td><?php echo e($kelas->nama); ?></td>
	    	</tr>
	    	<tr>
	    		<td>Siswa</td>
	    		<td><?php echo e($jumlah.' siswa'); ?></td>
	    	</tr>
	    	<tr>
	    		<td>Wali</td>
	    		<td><?php echo e($kelas->wali->nama); ?></td>
	    	</tr>
	    </table>
    </div>
  </div>
  <?php if($user->status == 'G'): ?>
  <div class="box box-danger">
    <div class="box-body">
	    <p><i class="fa fa-question-circle" style="color: indianred"></i> Apabila terdapat data siswa dalam kelas <b><?php echo e($kelas->nama); ?></b> ini tidak valid atau data nama kelas dan nama wali kelas, silahkan hubungi operator sekolah untuk melakukan perubahan pada data tersebut.</p>
    </div>
  </div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/plugins/datatables/media/css/dataTables.bootstrap.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/plugins/datatables/extensions/Responsive/css/responsive.dataTables.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/plugins/datatables/extensions/FixedHeader/css/fixedHeader.bootstrap.css')); ?>">

<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(URL::asset('assets/plugins/datatables/media/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatables/media/js/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatables/extensions/Responsive/js/dataTables.responsive.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatables/extensions/FixedHeader/js/dataTables.fixedHeader.js')); ?>"></script>
<script>
$(document).ready(function (){
	tabel_guru = $('#table_detail_kelas').DataTable({
    processing: true,
    serverSide: true,
    responsive: true,
    lengthChange: true,
    // ajax:'<?php echo route('master.detail_kelas_siswa'); ?>',
    ajax: {
      url: '<?php echo route('master.detail_kelas_siswa'); ?>',
      data: {"id_kelas": '<?php echo e($kelas->id); ?>'},
    },
    columns: [
      {data: 'nama', name: 'nama', orderable: true, searchable: true },
      {data: 'no_induk', name: 'no_induk', orderable: true, searchable: true },
      {data: 'nisn', name: 'nisn', orderable: true, searchable: true },
      {data: 'jk', name: 'jk', orderable: true, searchable: true },
      {data: 'action', name: 'action', orderable: false, searchable: false},
    ],
    "drawCallback": function (setting) {}
  });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CBTSMEPRI\resources\views/kelas/detail.blade.php ENDPATH**/ ?>