
<?php $__env->startSection('title', 'Error 404 - Halaman tidak ditemukan'); ?>
<?php $__env->startSection('breadcrumb'); ?>
  <h1>Error 404 - Halaman tidak ditemukan</h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(url('/home')); ?>"><i class="fa fa-home"></i> Home</a></li>
    <li class="active">Error 404 - Halaman tidak ditemukan</li>
  </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="col-md-12">
	  <div class="box box-default">
	    <div class="box-body">
	    	<div class="error-page">
	        <h2 class="headline text-yellow"> 404</h2>

	        <div class="error-content">
	          <h3><i class="fa fa-warning text-yellow"></i> Oops! Page not found.</h3>

	          <p>Kami tidak menemukan halaman yang Anda cari disini. Sementara itu, anda bisa <a href="<?php echo e(url('/')); ?>">kembali ke dashboard</a> atau kembali ke halaman sebelumnya.</p>
	          <p>Kemungkinan juga halaman ini belum selesai disiapkan/development. Silahkan hubungi operator aplikasi untuk mendapatkan informasi selengkapnya.</p>

	        </div>
	        <!-- /.error-content -->
	      </div>
	    </div>
	  </div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CBTSMEPRI\resources\views/errors/404.blade.php ENDPATH**/ ?>