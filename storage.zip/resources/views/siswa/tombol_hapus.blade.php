@if($cocok == 'Y')
	<button style="margin-top: 10px" class="btn btn-primary" id="delete-all">Hapus Semua Siswa</button>
@else
	<p style="margin-top: 10px" class="alert alert-danger">Password yang Anda inputkan tidak cocok!</p>
@endif